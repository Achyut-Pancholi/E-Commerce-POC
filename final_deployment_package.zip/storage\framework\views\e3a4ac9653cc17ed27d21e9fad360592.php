<?php $__env->startSection('title', $product->name . ' | E-Commerce POC'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm border-0">
            <?php if($product->image_path): ?>
                <img src="<?php echo e(Storage::url($product->image_path)); ?>" class="img-fluid rounded" alt="<?php echo e($product->name); ?>">
            <?php else: ?>
                <img src="<?php echo e(asset('images/placeholder.png')); ?>" class="img-fluid rounded" alt="Product Image">
            <?php endif; ?>
        </div>
    </div>
    
    <div class="col-md-6">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Products</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('products.index', ['category' => $product->category->slug])); ?>"><?php echo e($product->category->name); ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
            </ol>
        </nav>

        <h1 class="display-5 fw-bold"><?php echo e($product->name); ?></h1>
        <p class="text-muted lead"><?php echo e($product->category->name); ?></p>
        
        <h2 class="text-primary mb-4">$<?php echo e(number_format($product->price, 2)); ?></h2>
        
        <div class="mb-4">
            <h5>Description</h5>
            <p><?php echo e($product->description); ?></p>
        </div>
        
        <div class="mb-4">
            <span class="badge <?php echo e($product->stock_quantity > 0 ? 'bg-success' : 'bg-danger'); ?>">
                <?php echo e($product->stock_quantity > 0 ? 'In Stock (' . $product->stock_quantity . ')' : 'Out of Stock'); ?>

            </span>
        </div>

        <?php if($product->stock_quantity > 0): ?>
        <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST" class="d-flex align-items-center mb-4">
            <?php echo csrf_field(); ?>
            <div class="me-3">
                <input type="number" name="quantity" class="form-control" value="1" min="1" max="<?php echo e($product->stock_quantity); ?>" style="width: 80px;">
            </div>
            <button type="submit" class="btn btn-primary btn-lg px-5">
                <i class="fas fa-cart-plus me-2"></i> Add to Cart
            </button>
        </form>
        <?php else: ?>
            <button class="btn btn-secondary btn-lg px-5" disabled>Out of Stock</button>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\achyu\Desktop\E-Commerce\resources\views\products\show.blade.php ENDPATH**/ ?>