<?php $__env->startSection('title', 'My Orders | E-Commerce POC'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">My Orders</h2>

<?php if($orders->count() > 0): ?>
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>#<?php echo e(str_pad($order->id, 6, '0', STR_PAD_LEFT)); ?></td>
                                <td><?php echo e($order->created_at->format('M d, Y h:i A')); ?></td>
                                <td>
                                    <?php
                                        $badges = [
                                            'pending' => 'bg-warning text-dark',
                                            'confirmed' => 'bg-info text-dark',
                                            'shipped' => 'bg-primary',
                                            'delivered' => 'bg-success',
                                            'cancelled' => 'bg-danger'
                                        ];
                                    ?>
                                    <span class="badge <?php echo e($badges[$order->status] ?? 'bg-secondary'); ?>">
                                        <?php echo e(ucfirst($order->status)); ?>

                                    </span>
                                </td>
                                <td>$<?php echo e(number_format($order->total_amount, 2)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('orders.show', $order)); ?>" class="btn btn-sm btn-outline-primary">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-3">
                <?php echo e($orders->links()); ?>

            </div>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-info">You haven't placed any orders yet.</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\achyu\Desktop\E-Commerce\resources\views\orders\index.blade.php ENDPATH**/ ?>