<?php $__env->startSection('title', 'Products | E-Commerce POC'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Sidebar Filters -->
    <div class="col-md-3 mb-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <h5 class="card-title">Filter Products</h5>
                <form action="<?php echo e(route('products.index')); ?>" method="GET">
                    <div class="mb-3">
                        <label for="search" class="form-label">Search</label>
                        <input type="text" class="form-control" id="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Product name...">
                    </div>
                    <div class="mb-3">
                        <label for="category" class="form-label">Category</label>
                        <select class="form-select" id="category" name="category">
                            <option value="">All Categories</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->slug); ?>" <?php echo e(request('category') == $cat->slug ? 'selected' : ''); ?>>
                                    <?php echo e($cat->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
                    <?php if(request()->hasAny(['search', 'category'])): ?>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-link w-100 mt-2">Clear Filters</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <!-- Product Grid -->
    <div class="col-md-9">
        <h2 class="mb-4">Our Products</h2>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col">
                    <div class="card h-100 product-card shadow-sm">
                        <?php if($product->image_path): ?>
                            <img src="<?php echo e(Storage::url($product->image_path)); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/placeholder.png')); ?>" class="card-img-top" alt="Product Image">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            <p class="card-text text-muted small"><?php echo e($product->category->name); ?></p>
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <span class="fs-5 fw-bold">$<?php echo e(number_format($product->price, 2)); ?></span>
                                <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="btn btn-outline-primary btn-sm">Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="alert alert-info">No products found matching your criteria.</div>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="mt-4 d-flex justify-content-center">
            <?php echo e($products->withQueryString()->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\achyu\Desktop\E-Commerce\resources\views\products\index.blade.php ENDPATH**/ ?>