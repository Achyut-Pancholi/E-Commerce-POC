<?php $__env->startSection('title', 'Order details | E-Commerce POC'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Order #<?php echo e(str_pad($order->id, 6, '0', STR_PAD_LEFT)); ?></h2>
    <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-outline-secondary">Back to Orders</a>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Order Items</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('products.show', $item->product->slug)); ?>" class="text-decoration-none text-dark">
                                            <?php echo e($item->product->name); ?>

                                        </a>
                                    </td>
                                    <td>$<?php echo e(number_format($item->unit_price, 2)); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td>$<?php echo e(number_format($item->unit_price * $item->quantity, 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3" class="text-end">Subtotal:</th>
                                <th>$<?php echo e(number_format($order->total_amount, 2)); ?></th>
                            </tr>
                            <tr>
                                <th colspan="3" class="text-end">Shipping:</th>
                                <th>$0.00</th>
                            </tr>
                            <tr>
                                <th colspan="3" class="text-end fs-5">Total:</th>
                                <th class="fs-5">$<?php echo e(number_format($order->total_amount, 2)); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Order Summary</h5>
            </div>
            <div class="card-body">
                <p><strong>Date:</strong> <?php echo e($order->created_at->format('M d, Y h:i A')); ?></p>
                <p><strong>Status:</strong> 
                    <?php
                        $badges = [
                            'pending' => 'bg-warning text-dark',
                            'confirmed' => 'bg-info text-dark',
                            'shipped' => 'bg-primary',
                            'delivered' => 'bg-success',
                            'cancelled' => 'bg-danger'
                        ];
                    ?>
                    <span class="badge <?php echo e($badges[$order->status] ?? 'bg-secondary'); ?>">
                        <?php echo e(ucfirst($order->status)); ?>

                    </span>
                </p>
                <hr>
                <h6>Shipping Address</h6>
                <address class="mb-0">
                    <?php echo e($order->shipping_address['address'] ?? ''); ?><br>
                    <?php echo e($order->shipping_address['city'] ?? ''); ?><br>
                    <?php echo e($order->shipping_address['zip'] ?? ''); ?>

                </address>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\achyu\Desktop\E-Commerce\resources\views\orders\show.blade.php ENDPATH**/ ?>